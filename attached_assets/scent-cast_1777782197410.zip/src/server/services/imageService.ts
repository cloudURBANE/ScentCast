import axios from "axios";
import fs from "fs";
import FormData from "form-data";
import fetch from "node-fetch";

export async function searchImageUrl(query: string) {
  const apiKey = process.env.GOOGLE_API_KEY;
  const cx = process.env.GOOGLE_CSE_ID;

  // 1. Try Google Custom Search if configured
  if (apiKey && cx) {
    try {
      const response = await axios.get("https://www.googleapis.com/customsearch/v1", {
        params: {
          key: apiKey,
          cx: cx,
          q: `${query} single perfume bottle no box luxury hq official product photo white background`,
          searchType: "image",
          num: 1,
          imgSize: "large",
          safe: "active"
        }
      });

      const firstImage = response.data?.items?.[0]?.link;
      if (firstImage) return firstImage;
    } catch (err: any) {
      // API Key might be invalid or missing Custom Search permissions.
      // Silently fall back to Bing scraping
    }
  }

  // 2. Fall back to Bing Image Search Scraper (Free, No API Key needed)
  try {
    const cleanQuery = query.trim().replace(/\s+/g, ' ');
    // Remove quotes for more flexible matching, but keep specificity
    // Try to prioritize fragrantica or oficial sites by searching with them
    const bingQuery = `${cleanQuery} single fragrance bottle no box HQ product isolated white background`;
    const res = await fetch(`https://www.bing.com/images/search?q=${encodeURIComponent(bingQuery)}&form=HDRSC2&first=1&tsc=ImageHoverTitle`, {
      headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
      }
    });
    
    if (res.ok) {
        const text = await res.text();
        const matches = [...text.matchAll(/murl&quot;:&quot;(https?:\/\/[^&"]+?)&quot;/g)];
        if (matches.length > 0) {
            const urls = matches.map(m => m[1]);
            
            // Stock sites often have watermarks or generic placeholder-style photos
            const badHosts = ["dreamstime", "alamy", "shutterstock", "freepik", "istock", "pixelsquid", "123rf", "vecteezy", "ebay", "poshmark", "pinterest", "etsy"];
            
            // Known high-quality fragrance image hosts and official retailers
            const highTrustHosts = [
                "fragrantica.com", "fimgs.net", "sephora.com", "chanel.com", "dior.com", 
                "armani.com", "yslbeauty", "fragrancenet", "nordstrom", "neimanmarcus", 
                "bloomingdales", "saksfifthavenue", "ulta.com", "macys.com", "harrods.com",
                "selfridges.com", "johnlewis.com", "douglas.de"
            ];
            
            // Prioritize high-trust hosts
            const highTrustUrl = urls.find(u => highTrustHosts.some(h => u.toLowerCase().includes(h)));
            if (highTrustUrl) return highTrustUrl;

            // Remove potentially low-quality or off-topic sites
            const filtered = urls.filter(u => !badHosts.some(bh => u.toLowerCase().includes(bh)));
            if (filtered.length > 0) {
                // Prefer clean direct image links
                const bestCandidate = filtered.find(u => /\.(jpg|png|webp|jpeg)(\?.*)?$/i.test(u)) || filtered[0];
                return bestCandidate;
            }
            return matches[0][1];
        }
    }
  } catch (err) {
    console.warn("[ImageService] Bing image search fallback failed.", err);
  }

  // 3. Ultimate fallback - first try a generic Unsplash search with the brand included
  const q = query.toLowerCase();
  const searchTerms = q.replace(/[^a-z0-9]/g, '+');
  
  // Specific curated fallback IDs for top brands if everything else fails
  let photoId = ""; 
  if (q.includes("chanel") || q.includes("n°5")) photoId = "vInYhC07U1Q"; 
  else if (q.includes("dior") || q.includes("sauvage")) photoId = "1523293182086-7651a899d37f";
  else if (q.includes("versace")) photoId = "1594035910387-fea47794261f";
  
  if (photoId) {
    return `https://images.unsplash.com/photo-${photoId}?auto=format&fit=crop&q=100&w=1200`;
  }

  return `https://images.unsplash.com/featured/?perfume,bottle,${searchTerms}&auto=format&fit=crop&q=100&w=1200`;
}

export async function searchImage(filePath: string) {
  // We no longer use external image search APIs. 
  // Vision analysis is handled directly via Gemini in geminiService.ts
  return [];
}
