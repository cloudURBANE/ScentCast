
/**
 * Manages multiple Gemini API keys and handles rotation on failure.
 */
class KeyManager {
  private keys: string[] = [];
  private currentIdx = 0;
  private exhaustedKeys = new Map<number, number>(); // index -> timestamp
  private invalidKeys = new Set<number>(); // index of keys that returned 401/400
  private COOLDOWN_MS = 120000; // Increased to 2 minutes cooldown for quota errors

  constructor() {
    this.refreshKeys();
  }

  /**
   * Refreshes the list of keys from environment variables.
   */
  public refreshKeys() {
    const rawKeys = [
      process.env.GEMINI_API_KEY,
      process.env.GEMINI_API_KEY_2,
      process.env.GEMINI_API_KEY_3,
    ].filter((k): k is string => !!k && k.length > 0);

    const allKeys: string[] = [];
    for (const key of rawKeys) {
      if (!key || key.includes("YOUR_API_KEY") || key.includes("INSERT_KEY") || key.length < 10) continue;
      const parts = key.split(/[;,]/).map(k => k.trim()).filter(k => k.length > 0);
      allKeys.push(...parts);
    }

    // Filter out duplicates
    this.keys = Array.from(new Set(allKeys));
    this.currentIdx = 0;
    this.exhaustedKeys.clear();
    this.invalidKeys.clear();
    
    console.log(`KeyManager initialized with ${this.keys.length} unique keys found.`);
  }

  private cleanupExhausted() {
    const now = Date.now();
    for (const [idx, time] of this.exhaustedKeys.entries()) {
      if (now - time > this.COOLDOWN_MS) {
        this.exhaustedKeys.delete(idx);
        console.log(`Gemini API key #${idx + 1} cooldown expired. Returning to pool.`);
      }
    }
  }

  /**
   * Returns the current active key.
   */
  public getCurrentKey(): string {
    this.cleanupExhausted();
    if (this.keys.length === 0) {
      throw new Error("No Gemini API keys found. Please check your environment variables.");
    }
    
    // If current is bad, find next one
    if (this.exhaustedKeys.has(this.currentIdx) || this.invalidKeys.has(this.currentIdx)) {
      this.findNextIdx();
    }
    
    return this.keys[this.currentIdx];
  }

  private findNextIdx(): boolean {
    let nextIdx = (this.currentIdx + 1) % this.keys.length;
    let checkedCount = 0;
    
    while ((this.exhaustedKeys.has(nextIdx) || this.invalidKeys.has(nextIdx)) && checkedCount < this.keys.length) {
      nextIdx = (nextIdx + 1) % this.keys.length;
      checkedCount++;
    }
    
    if (checkedCount >= this.keys.length) {
      return false;
    }
    
    this.currentIdx = nextIdx;
    return true;
  }

  public markQuotaExhausted(): boolean {
    this.exhaustedKeys.set(this.currentIdx, Date.now());
    return this.findNextIdx();
  }

  public markInvalid(): boolean {
    console.warn(`Gemini API key #${this.currentIdx + 1} marked as INVALID.`);
    this.invalidKeys.add(this.currentIdx);
    return this.findNextIdx();
  }

  public rotateKey(): boolean {
    return this.markQuotaExhausted();
  }

  public getStatus() {
    this.cleanupExhausted();
    return {
      total: this.keys.length,
      available: this.keys.length - this.exhaustedKeys.size - this.invalidKeys.size,
      exhausted: this.exhaustedKeys.size,
      invalid: this.invalidKeys.size,
      currentNum: this.currentIdx + 1
    };
  }
}

export const keyManager = new KeyManager();
