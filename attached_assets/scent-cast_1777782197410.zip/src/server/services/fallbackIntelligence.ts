import axios from 'axios';
import * as cheerio from 'cheerio';

export async function deepScrapeFragrance(query: string) {
  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query + " perfume or fragrance")}&utf8=&format=json`;
    const res = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'OlfactoryApp/1.0 (Contact: local@example.com)'
      }
    });

    let snippet = '';
    if (res.data?.query?.search?.length > 0) {
      snippet = res.data.query.search.map((s: any) => s.snippet).join(' ');
      // strip html tags from snippet
      snippet = snippet.replace(/<[^>]+>/g, '');
    }

    // Extract potential notes
    const lowerSnippet = snippet.toLowerCase();
    
    // Very basic keyword extraction for mock AI
    const possibleNotes = ['vanilla', 'rose', 'sandalwood', 'bergamot', 'lemon', 'patchouli', 'musk', 'jasmine', 'oud', 'amber', 'cedar', 'vetiver', 'leather', 'tonka', 'lavender', 'iris', 'pear', 'apple', 'pepper', 'neroli', 'tuberose', 'ylang', 'cardamom', 'citrus', 'wood'];
    const foundNotes = possibleNotes.filter(n => lowerSnippet.includes(n));

    // Simple heuristic for name/brand
    let parts = query.split(' ');
    let brand = parts[0] || "Unknown";
    let name = parts.slice(1).join(' ') || parts[0];

    return {
      name,
      brand,
      notes: foundNotes.length > 0 ? foundNotes : ['Citrus', 'Wood', 'Musk'],
      family: foundNotes.includes('wood') || foundNotes.includes('sandalwood') ? 'Woody' : (foundNotes.includes('rose') || foundNotes.includes('jasmine') ? 'Floral' : 'Fresh'),
      description: snippet ? `Scent notes derived from Wikipedia concepts. Description: ${snippet.substring(0, 200)}...` : `Standard profile for ${query} based on heuristic text approximation.`
    };
  } catch (err: any) {
    console.error("Deep scrape failed, returning fallback:", err.message);
    
    let parts = query.split(' ');
    let brand = parts[0] || "Unknown";
    let name = parts.slice(1).join(' ') || parts[0];

    return {
      name,
      brand,
      notes: ['Citrus', 'Wood', 'Musk'],
      family: 'Fresh',
      description: `Basic heuristic profile for ${query}.`
    };
  }
}

export async function ocrImage(base64Image: string, mimeType: string) {
  try {
    // Tesseract.js often times out or crashes the server when downloading language models in this environment.
    // Returning a mock response to ensure the server remains stable.
    return [
      {
        name: "Scanned Perfume",
        brand: "Unknown Brand",
        notes: ["citrus", "floral", "wood", "musk"],
        description: "OCR model download disabled in fallback mode. Mock analysis provided.",
        imageUrl: ""
      }
    ];
  } catch (err: any) {
    console.error("OCR failed:", err.message);
    throw err;
  }
}
