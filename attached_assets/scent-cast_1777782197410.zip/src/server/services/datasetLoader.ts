import fs from "fs";
import path from "path";

export interface FragranceData {
  name: string;
  brand: string;
  family: string;
  notes: string[];
  pyramid?: {
    top: string[];
    heart: string[];
    base: string[];
  };
  description: string;
  imageUrl?: string;
}

let cachedDataset: FragranceData[] | null = null;

export function loadDataset(): FragranceData[] {
  if (cachedDataset) return cachedDataset;
  try {
    const filePath = path.join(process.cwd(), "src/server/data/fragrances.json");
    const raw = fs.readFileSync(filePath, "utf-8");
    cachedDataset = JSON.parse(raw);
    return cachedDataset || [];
  } catch (err) {
    console.error("Error loading fragrance dataset:", err);
    return [];
  }
}
