import { loadDataset, type FragranceData } from "./datasetLoader.ts";
import { parseFragrance } from "./scentParser.ts";
import { vectorize, calculatePerformance, calculateContext, type ScentVector, type PerformanceMetrics, type ContextProfile } from "./scentVectorizer.ts";
import { searchImageUrl } from "./imageService.ts";
import { removeBg } from "./bgService.ts";

export interface ScentProfile {
  product: {
    name: string;
    brand: string;
  };
  scent_vector: ScentVector;
  performance: PerformanceMetrics;
  context: ContextProfile;
  notes: string[];
  pyramid?: {
    top: string[];
    heart: string[];
    base: string[];
  };
  family: string;
  imageUrl?: string;
  description?: string;
  error?: string;
}

function findFragrance(name: string, brand: string): FragranceData | undefined {
  const dataset = loadDataset();
  const searchName = name.toLowerCase();
  const searchBrand = brand.toLowerCase();
  const combined = `${brand} ${name}`.toLowerCase().trim();

  return dataset.find(item => {
    const itemName = item.name.toLowerCase();
    const itemBrand = item.brand.toLowerCase();
    const full = `${itemBrand} ${itemName}`.toLowerCase();
    
    // Fuzzy match: exact brand + name containment OR perfect name match OR combined match
    return (itemBrand === searchBrand && itemName.includes(searchName)) ||
           (brand === "" && itemName.includes(searchName)) ||
           (brand === "" && full.includes(searchName)) ||
           (itemName === searchName) ||
           (full === combined);
  });
}

export function searchFragrances(query: string): FragranceData[] {
  const dataset = loadDataset();
  const q = query.toLowerCase();
  
  return dataset.filter(item => {
    const itemName = item.name.toLowerCase();
    const itemBrand = item.brand.toLowerCase();
    const full = `${itemBrand} ${itemName}`.toLowerCase();
    
    return itemName.includes(q) || 
           itemBrand.includes(q) ||
           full.includes(q) ||
           q.includes(itemName) && q.includes(itemBrand);
  });
}

export async function buildProfile(
  name: string, 
  brand: string, 
  fallback?: { notes?: string[], family?: string, description?: string, imageUrl?: string, pyramid?: any }
): Promise<ScentProfile | { error: string }> {
  // STEP 1: RESEARCH & BEST ASSETS (Fallback Only)
  let researchData = fallback;
  let researchName = name;
  let researchBrand = brand;

  // STEP 2: IMAGE ACQUISITION
  let finalImageUrl = fallback?.imageUrl;
  
  try {
    // Boost search query with quality terms
    const searchQuery = `${researchBrand} ${researchName} single fragrance bottle no box HQ`;
    console.log(`[Research] Looking up official assets for: ${searchQuery}`);
    const searchRes = await searchImageUrl(searchQuery);
    if (searchRes && !searchRes.includes('unsplash-placeholder')) {
      finalImageUrl = searchRes;
    } else if (researchData?.imageUrl) {
      finalImageUrl = researchData.imageUrl;
    }
  } catch (err) {
    console.warn("Image lookup failed, using research data fallback", err);
    finalImageUrl = researchData?.imageUrl || fallback?.imageUrl;
  }

  // STEP 3: VISUAL SYNTHESIS (REMOVE BG)
  let cleanImageUrl = finalImageUrl;
  if (finalImageUrl && !finalImageUrl.includes('unsplash-placeholder')) {
    try {
      console.log(`[Visual] Synthesizing asset for: ${researchBrand} ${researchName}`);
      const bgResult = await removeBg(finalImageUrl, true);
      if (bgResult.cleanImage) {
        cleanImageUrl = bgResult.cleanImage;
      }
    } catch (err: any) {
      console.warn("BG Removal skipped:", err.message);
    }
  }

  // STEP 4: LOCAL SEARCH / COLLATION
  const match = findFragrance(researchName, researchBrand);
  
  // Merge Strategy: Local Dataset > Fallback/Input
  const finalName = match?.name || researchName;
  const finalBrand = match?.brand || researchBrand;
  const finalNotes = match?.notes || researchData?.notes || [];
  const finalFamily = match?.family || researchData?.family || "Unknown Family";
  const finalDescription = match?.description || researchData?.description || "";
  const finalPyramid = match?.pyramid || researchData?.pyramid;

  // Validate we have enough to build a profile
  if (!match && (!researchData || !researchData.notes)) {
    return {
      error: "Could not identify this fragrance. Try a more specific name."
    };
  }

  // STEP 5: PARSE & VECTORIZE
  const parsed = parseFragrance({
    name: finalName,
    brand: finalBrand,
    notes: finalNotes,
    family: finalFamily,
    description: finalDescription
  } as FragranceData);
  
  if (!parsed) return { error: "Failed to parse data" };

  const vector = vectorize(parsed);
  const performance = calculatePerformance(vector, finalFamily);
  const context = calculateContext(vector);

  return {
    product: {
      name: finalName,
      brand: finalBrand
    },
    scent_vector: vector,
    performance,
    context,
    notes: finalNotes,
    pyramid: finalPyramid,
    family: finalFamily,
    imageUrl: cleanImageUrl,
    description: finalDescription
  };
}
