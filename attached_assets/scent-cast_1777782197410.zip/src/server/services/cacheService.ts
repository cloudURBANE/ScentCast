
import fs from 'fs';
import path from 'path';

const CACHE_DIR = path.join(process.cwd(), 'cache');
if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR);
}

export class CacheService {
  private cache = new Map<string, { data: any, expires: number }>();
  private cacheFile = path.join(CACHE_DIR, 'gemini_cache.json');

  constructor() {
    this.loadFromDisk();
  }

  private loadFromDisk() {
    try {
      if (fs.existsSync(this.cacheFile)) {
        const raw = fs.readFileSync(this.cacheFile, 'utf-8');
        const parsed = JSON.parse(raw);
        this.cache = new Map(Object.entries(parsed));
      }
    } catch (e) {
      console.warn("Failed to load Gemini cache from disk", e);
    }
  }

  private saveToDisk() {
    try {
      const obj = Object.fromEntries(this.cache.entries());
      fs.writeFileSync(this.cacheFile, JSON.stringify(obj));
    } catch (e) {
      console.warn("Failed to save Gemini cache to disk", e);
    }
  }

  public get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expires) {
      this.cache.delete(key);
      return null;
    }
    return entry.data;
  }

  public set(key: string, data: any, ttlDays: number = 7) {
    const expires = Date.now() + (ttlDays * 24 * 60 * 60 * 1000);
    this.cache.set(key, { data, expires });
    this.saveToDisk();
  }
}

export const geminiCache = new CacheService();
