import axios from "axios";
import fs from "fs";
import FormData from "form-data";
import sharp from "sharp";

/**
 * Normalizes a fragrance bottle image:
 * 1. Trims transparent/white edges
 * 2. Resizes to a standard 600x600 canvas
 * 3. Centers the bottle with consistent padding
 */
async function normalizeImage(buffer: Buffer): Promise<Buffer> {
  try {
    // First pass: trim and get dimensions
    const image = sharp(buffer);
    
    // Trim based on transparency (if BG was removed) OR based on light background
    // We try to trim with a slight threshold to catch near-white backgrounds
    const processed = await image
      .trim({ threshold: 10 }) // Slightly more robust against near-white backgrounds
      .resize(500, 500, {
        fit: "contain",
        background: { r: 0, g: 0, b: 0, alpha: 0 }
      })
      .extend({
        top: 50, bottom: 50, left: 50, right: 50, // Standardized padding
        background: { r: 0, g: 0, b: 0, alpha: 0 }
      })
      .png()
      .toBuffer();
      
    return processed;
  } catch (err) {
    console.warn("[BGService] Normalization failed, returning original buffer", err);
    return buffer;
  }
}

export async function removeBg(input: string, isUrl = false) {
  const apiKey = process.env.REMOVE_BG_API_KEY;
  
  // Helper to convert buffer to data URI
  const toDataUri = (buffer: Buffer, originalType = "image/png") => {
    return `data:${originalType};base64,${buffer.toString("base64")}`;
  };

  // 1. Fetch the raw image first to normalize it even if BG removal is skipped
  let rawBuffer: Buffer;
  let contentType = "image/jpeg";

  try {
    if (isUrl && input.startsWith("http")) {
      const res = await axios.get(input, { 
        responseType: 'arraybuffer', 
        timeout: 8000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
        }
      });
      rawBuffer = Buffer.from(res.data);
      contentType = (res.headers['content-type'] as string) || 'image/jpeg';
    } else if (isUrl && input.startsWith("data:")) {
      const parts = input.split(",");
      rawBuffer = Buffer.from(parts[1], "base64");
      contentType = parts[0].split(":")[1].split(";")[0];
    } else if (!isUrl && fs.existsSync(input)) {
        rawBuffer = fs.readFileSync(input);
    } else {
        return { cleanImage: input };
    }
  } catch (err) {
    console.error("[BGService] Failed to fetch image for processing:", err);
    return { cleanImage: input };
  }
  
  // Use lazy download/proxy if No API Key is found
  if (!apiKey) {
    const normalized = await normalizeImage(rawBuffer);
    return { cleanImage: toDataUri(normalized, "image/png") };
  }

  try {
    const formData = new FormData();
    formData.append("image_file", rawBuffer, "image.jpg");
    formData.append("size", "auto");
    formData.append("type", "product"); // Optimize for product shots

    const response = await axios.post("https://api.remove.bg/v1.0/removebg", formData, {
      headers: {
        ...formData.getHeaders(),
        "X-Api-Key": apiKey,
      },
      responseType: "arraybuffer",
      timeout: 20000,
      validateStatus: (status) => status < 500
    });

    if (response.status !== 200) {
      const errorStr = Buffer.from(response.data).toString();
      console.error(`BG removal API returned ${response.status}:`, errorStr);
      // Even if API fails, normalize the original
      const normalized = await normalizeImage(rawBuffer);
      return { cleanImage: toDataUri(normalized, "image/png") };
    }

    const removedBgBuffer = Buffer.from(response.data);
    const normalized = await normalizeImage(removedBgBuffer);
    
    return {
      cleanImage: toDataUri(normalized, "image/png")
    };
  } catch (err: any) {
    console.error("BG removal API exception:", err.message);
    const normalized = await normalizeImage(rawBuffer);
    return { cleanImage: toDataUri(normalized, "image/png") };
  }
}
