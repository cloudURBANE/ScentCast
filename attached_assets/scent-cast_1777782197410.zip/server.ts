import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import multer from "multer";
import dotenv from "dotenv";
import { getWeather } from "./src/server/services/weatherService.ts";
import { searchImage, searchImageUrl } from "./src/server/services/imageService.ts";
import { removeBg } from "./src/server/services/bgService.ts";
import { buildProfile, searchFragrances } from "./src/server/services/scentEngine.ts";
import { deepScrapeFragrance, ocrImage } from "./src/server/services/fallbackIntelligence.ts";

dotenv.config();

const upload = multer({ dest: "uploads/" });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // API Routes
  app.get("/api/weather", async (req, res) => {
    try {
      const { lat, lon } = req.query;
      const data = await getWeather({ lat, lon } as any);
      res.json(data);
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: "Weather failed", message: err.message });
    }
  });

  app.post("/api/search-local", async (req, res) => {
    try {
      const { query } = req.body;
      const matches = searchFragrances(query).map(m => ({
        ...m,
        // Pre-fill a dynamic Unsplash URL for preview if missing
        imageUrl: m.imageUrl || `https://images.unsplash.com/featured/?perfume,bottle,${m.brand.replace(/\s/g, '+')},${m.name.replace(/\s/g, '+')}&auto=format&fit=crop&q=80&w=400`
      }));
      res.json(matches);
    } catch (err: any) {
      console.error(err.message);
      res.status(500).json({ error: "Local search failed", message: err.message });
    }
  });

  app.post("/api/image-search", upload.single("image"), async (req: any, res) => {
    try {
      if (!req.file) throw new Error("No image provided");
      const result = await searchImage(req.file.path);
      res.json(result);
    } catch (err: any) {
      console.error(err.message);
      res.status(500).json({ error: "Image search failed", message: err.message });
    }
  });

  app.post("/api/remove-bg", upload.single("image"), async (req: any, res) => {
    try {
      if (req.file) {
        const result = await removeBg(req.file.path, false);
        res.json(result);
      } else if (req.body.imageUrl) {
        const result = await removeBg(req.body.imageUrl, true);
        res.json(result);
      } else {
        throw new Error("No image or URL provided");
      }
    } catch (err: any) {
      console.error(err.message);
      res.status(500).json({ error: "BG removal failed", message: err.message });
    }
  });

  app.post("/api/scent-profile", async (req, res) => {
    try {
      const { name, brand, notes, family, description, imageUrl, pyramid } = req.body;
      const profile = await buildProfile(name, brand, { notes, family, description, imageUrl, pyramid } as any);
      res.json(profile);
    } catch (err: any) {
      console.error(err.message);
      res.status(500).json({ error: "Scent profile generation failed", message: err.message });
    }
  });

  app.post("/api/search-scent", async (req, res) => {
    try {
      const { query } = req.body;
      const profile = await buildProfile(query, ""); 
      res.json(profile);
    } catch (err: any) {
      console.error(err.message);
      res.status(500).json({ error: "Search failed", message: err.message });
    }
  });

  app.post("/api/search-deep", async (req, res) => {
    try {
      const { query } = req.body;
      const profile = await deepScrapeFragrance(query);
      res.json(profile);
    } catch (err: any) {
      console.error("[DeepSearch] Failed:", err.message);
      res.status(500).json({ error: "Deep search failed", message: err.message });
    }
  });

  app.post("/api/analyze-vision", async (req, res) => {
    try {
      const { base64, mimeType } = req.body;
      const results = await ocrImage(base64, mimeType);
      res.json(results);
    } catch (err: any) {
      console.error("[Vision] Failed:", err.message);
      res.status(500).json({ error: "Vision analysis failed", message: err.message });
    }
  });

  app.get("/api/test-keys", async (req, res) => {
    const results: any = {
      gemini: { configured: false, status: "unknown", message: "" },
      googleCustomSearch: { configured: false, status: "unknown", message: "" }
    };

    // Test Gemini
    const geminiKey = process.env.GEMINI_API_KEY;
    if (geminiKey) {
      results.gemini.configured = true;
      try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contents: [{ parts: [{ text: "Hello" }] }] })
        });
        
        if (response.ok) {
          results.gemini.status = "ok";
          results.gemini.message = "Successfully connected to Gemini API";
        } else {
          const errorData: any = await response.json().catch(() => ({}));
          results.gemini.status = "error";
          results.gemini.message = `HTTP ${response.status}: ${errorData?.error?.message || response.statusText}`;
        }
      } catch (err: any) {
        results.gemini.status = "error";
        results.gemini.message = err.message;
      }
    } else {
      results.gemini.message = "GEMINI_API_KEY is not set";
    }

    // Test Google Custom Search
    const googleKey = process.env.GOOGLE_API_KEY;
    const cx = process.env.GOOGLE_CSE_ID;
    
    if (googleKey && cx) {
      results.googleCustomSearch.configured = true;
      try {
        const response = await fetch(`https://www.googleapis.com/customsearch/v1?key=${googleKey}&cx=${cx}&q=test&searchType=image&num=1`);
        
        if (response.ok) {
          results.googleCustomSearch.status = "ok";
          results.googleCustomSearch.message = "Successfully connected to Google Custom Search";
        } else {
          const errorData: any = await response.json().catch(() => ({}));
          results.googleCustomSearch.status = "error";
          results.googleCustomSearch.message = `HTTP ${response.status}: ${errorData?.error?.message || response.statusText}`;
        }
      } catch (err: any) {
        results.googleCustomSearch.status = "error";
        results.googleCustomSearch.message = err.message;
      }
    } else {
      results.googleCustomSearch.message = "GOOGLE_API_KEY or GOOGLE_CSE_ID is not set";
    }

    res.json(results);
  });

  app.post("/api/chat", async (req, res) => {
    res.json({ text: "Hey there! I am operating in low-power fallback mode without Gemini. I can't think deeply right now, but you can still search the catalog or use text recognition on images!" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Increase timeout for long-running calls
  server.timeout = 120000;
}

startServer();
